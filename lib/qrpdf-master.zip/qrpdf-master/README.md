qrpdf
=====

Creating PDF labels with QR codes via fpdf

## Background

The idea behind this draft is to easily create labels with qr codes generated from CSV data. Right now it's no more than a proof of concept.

Background (in German): http://infobib.de/blog/2012/12/07/individuelle-qr-codes-in-serienbriefen/

Please feel free to improve! A csv upload would be nice, and a small tool to set up the pdf properties.